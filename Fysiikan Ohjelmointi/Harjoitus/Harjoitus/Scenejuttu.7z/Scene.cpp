#include "Scene.h"

Scene::Scene(void)
{
}


Scene::~Scene(void)
{
}

